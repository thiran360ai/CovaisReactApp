import React, { useState } from 'react';
import './Gym.css';
import { Container, Row, Col, Form, Button, Card, Carousel } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import photo1 from './imgs/pho1.jpeg';
import photo2 from './imgs/pho2.jpeg';
import photo3 from './imgs/pho3.jpeg';
import photo4 from './imgs/pho4.jpeg';
import photo5 from './imgs/pho5.jpeg';
import photo6 from './imgs/pho6.jpeg';

function App() {
  const [showBookingForm, setShowBookingForm] = useState(false);

  const handleBookNowClick = () => {
    setShowBookingForm(true);
  };

  const handleBackToHomeClick = () => {
    setShowBookingForm(false);
  };

  if (showBookingForm) {
    return <BookingForm handleBackToHomeClick={handleBackToHomeClick} />;
  }

  return (
    <div>
      {/* Navigation Bar */}
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <a className="navbar-brand" href="#">My Gym</a>
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav mr-auto">
            <li className="nav-item">
              <a className="nav-link" href="#">Home</a>
            </li>
            {/* Add more navigation items here if needed */}
          </ul>
        </div>
      </nav>

      {/* Slider Component */}
      <Carousel>
        <Carousel.Item>
          <img className="d-block w-100" src={photo1} alt="First slide" />
          <Carousel.Caption>
            <h3>Welcome to Our Gym</h3>
            <p>Get fit with the best equipment and trainers.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={photo2} alt="Second slide" />
          <Carousel.Caption>
            <h3>State-of-the-Art Equipment</h3>
            <p>We offer the latest in fitness technology.</p>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img className="d-block w-100" src={photo3} alt="Third slide" />
          <Carousel.Caption>
            <h3>Expert Trainers</h3>
            <p>Our trainers are here to guide you every step of the way.</p>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      {/* Card Component */}
      <Container className="mt-4">
        <div className="d-flex justify-content-around flex-wrap">
          <Card style={{ width: '18rem', margin: '10px' }}>
            <Card.Img variant="top" src={photo5} />
            <Card.Body>
              <Card.Title>Personal Training</Card.Title>
              <Card.Text>
                Personal training is a personalized approach to fitness that provides tailored guidance, motivation, and accountability to help individuals achieve their specific health goals. Whether it's cardio-based, strength training, yoga, or dance.
              </Card.Text>
              <Button variant="primary" onClick={handleBookNowClick}>Book Now</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: '18rem', margin: '10px' }}>
            <Card.Img variant="top" src={photo4} />
            <Card.Body>
              <Card.Title>Group Classes</Card.Title>
              <Card.Text>
                Motivating group sessions led by expert instructors. Select classes that align with your fitness level, interests, and goals. Whether it's cardio-based, strength training, yoga, or dance.
              </Card.Text>
              <Button variant="primary" onClick={handleBookNowClick}>Book Now</Button>
            </Card.Body>
          </Card>
          <Card style={{ width: '18rem', margin: '10px' }}>
            <Card.Img variant="top" src={photo6} />
            <Card.Body>
              <Card.Title>Nutritional Guidance</Card.Title>
              <Card.Text>
                Customized diet plans for optimal health and fitness. Encourage a balanced intake of carbohydrates, proteins, fats, vitamins, and minerals to support overall health and energy levels.
              </Card.Text>
              <Button variant="primary" onClick={handleBookNowClick}>Book Now</Button>
            </Card.Body>
          </Card>
        </div>
      </Container>

      {/* Login Form */}
      <Container className="mt-5">
        <Row>
          <Col>
            <h2>Login</h2>
            <Form>
              <Form.Group controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" />
                <Form.Text className="text-muted">
                  We'll never share your email with anyone else.
                </Form.Text>
              </Form.Group>

              <Form.Group controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password" />
              </Form.Group>

              <Button variant="primary" type="submit">
                Login
              </Button>
            </Form>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

const BookingForm = ({ handleBackToHomeClick }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    address: '',
    date: '',
    time: '',
    payment: '', // Assuming payment information can be a text input, e.g., credit card details
  });

  const [showConfirmation, setShowConfirmation] = useState(false); // State for showing confirmation message

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add code to handle form submission (e.g., send data to backend)
    console.log(formData);
    // Reset form fields
    setFormData({
      name: '',
      email: '',
      mobile: '',
      address: '',
      date: '',
      time: '',
      payment: '',
    });
    // Show confirmation message
    setShowConfirmation(true);

    // Clear confirmation message after 3 seconds
    setTimeout(() => {
      setShowConfirmation(false);
    }, 3000);
  };

  return (
    <div className="form-container">
      <Button variant="secondary" onClick={handleBackToHomeClick}>Back to Home</Button>
      <form onSubmit={handleSubmit}>
        <label>
          Name:
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Email:
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Mobile Number:
          <input
            type="tel"
            name="mobile"
            value={formData.mobile}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Address:
          <textarea
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Date:
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Time:
          <input
            type="time"
            name="time"
            value={formData.time}
            onChange={handleChange}
            required
          />
        </label>
        <label>
          Payment Information:
          <input
            type="text"
            name="payment"
            value={formData.payment}
            onChange={handleChange}
            required
          />
        </label>
        <button type="submit">Book Now</button>
      </form>

      {/* Confirmation Message */}
      {showConfirmation && (
        <div className="confirmation-message">
          <p>Your booking has been confirmed!</p>
        </div>
      )}
    </div>
  );
};

export default App;
