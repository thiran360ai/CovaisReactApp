// CardList.js
import React from 'react';
import './about.css'; // Ensure this is the correct path to your CSS file
import logo from './img/logo.jpg';
const CardList = () => {
  const cards = [
    {
      id: 1,
      image: 'https://play-lh.googleusercontent.com/MWV1erZURmTaeXGj29ZLWMSo_7DB92q3IL71lDSRooqbb3qidsa4c9DJ0_jEQgOeXEQ',
      title: 'Whatsapp',
      tagline: 'Whatsapp',
      status: 'Active',
      description: 'This is a brief description for card 1. It provides a short overview of the card content.'
    },
    {
      id: 2,
      image: 'https://images.indianexpress.com/2023/07/Instagram-logo.jpg?w=414',
      title: 'Instagram',
      tagline: 'Instagram',
      status: 'Inactive',
      description: 'This is a brief description for card 2. It provides a short overview of the card content.'
    },
    {
      id: 3,
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQj1XU5C8qUiT4vLQuKyF22Z3bObuN2aQP3ZA&s',
      title: 'Discord',
      tagline: 'Discord',
      status: 'Pending',
      description: 'This is a brief description for card 3. It provides a short overview of the card content.'
    }
  ];

  return (
    <ul className="cards">
      {cards.map(card => (
        <li key={card.id} className="card">
          <img src={card.image} alt={card.title} className="card__image" />
          <div className="card__overlay">
            <div className="card__header">
              <img src={logo} alt={card.title} className="card__thumb" />
              <div>
                <h3 className="card__title">{card.title}</h3>
                <span className="card__tagline">{card.tagline}</span>
                <span className="card__status">{card.status}</span>
              </div>
              <svg className="card__arc" viewBox="0 0 80 80">
                <path d="M 40 80 c 22 0 40 -22 40 -40 v 40 Z" />
              </svg>
            </div>
            <p className="card__description">{card.description}</p>
          </div>
        </li>
      ))}
    </ul>
  );
};

export default CardList;
